<?php 
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

function tema_girasalud_scripts() {
    // Enlazar el archivo style.css del tema
    wp_enqueue_style('tema-girasalud-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'tema_girasalud_scripts');

// Ganchos para el encabezado
function mi_tema_head() {
    echo '<meta charset="' . get_bloginfo( 'charset' ) . '">' . "\n";    
    echo '<meta test="sebitas">' . "\n";
}
add_action('wp_head', 'mi_tema_head');

// Ganchos para el cuerpo principal
function mi_tema_body_start() {
    echo('<h1>Hola</h1>');
}
add_action('wp_body_open', 'mi_tema_body_start');

function mi_tema_body_end() {
    echo('<h1>Region de scripts</h1>');
}
add_action('wp_footer', 'mi_tema_body_end');

/**
 * El Loop de WordPress
 * Este es el bucle básico para mostrar entradas.
 */
function mi_tema_loop() {
    if (have_posts()) {
        while (have_posts()) {
            the_post();
            ?>
            <div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
                <div class="entry-content">
                    <?php the_content(); ?>
                </div>
            </div>
            <?php
        }
    } else {
        ?>
        <h2>No se encontraron entradas</h2>
        <?php
    }
}